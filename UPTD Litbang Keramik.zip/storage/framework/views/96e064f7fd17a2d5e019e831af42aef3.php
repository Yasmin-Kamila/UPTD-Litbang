<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login Admin - UPTD Litbang Keramik</title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet"
          href="<?php echo e(asset('css/login.css')); ?>">

</head>


<body>

<div class="login-page">


    <!-- ================= LOGO ================= -->

    <div class="login-logo">

        <img
            src="<?php echo e(asset('images/logo.png')); ?>"
            alt="Logo UPTD Litbang Keramik">

    </div>


    <!-- ================= JUDUL ================= -->

    <h1>HALAMAN LOGIN</h1>

    <p class="login-subtitle">
        Login Admin UPTD Litbang Keramik
    </p>


    <!-- ================= LOGIN CONTAINER ================= -->

    <section class="login-container">

        <div class="login-form">


            <!-- ================= PESAN ERROR ================= -->

            <?php if(session('error')): ?>

                <div class="alert">

                    <i class="fa-solid fa-circle-exclamation"></i>

                    <?php echo e(session('error')); ?>


                </div>

            <?php endif; ?>


            <?php if($errors->any()): ?>

                <div class="alert">

                    <ul>

                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li>
                                <?php echo e($error); ?>

                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>

                </div>

            <?php endif; ?>


            <!-- ================= FORM LOGIN ================= -->

            <form
                action="<?php echo e(route('login.process')); ?>"
                method="POST"
                autocomplete="off">

                <?php echo csrf_field(); ?>


                <!-- ================= NAMA ================= -->

                <div class="form-group">

                    <label for="nama">

                        <i class="fa-solid fa-user"></i>

                        Nama

                    </label>

                    <input
                        type="text"
                        id="nama"
                        name="nama"
                        placeholder="Masukkan nama"
                        autocomplete="off"
                        required>

                </div>


                <!-- ================= USERNAME ================= -->

                <div class="form-group">

                    <label for="username">

                        <i class="fa-solid fa-user"></i>

                        Username

                    </label>

                    <input
                        type="text"
                        id="username"
                        name="username"
                        value="<?php echo e(old('username')); ?>"
                        placeholder="Masukkan username"
                        autocomplete="off"
                        required>

                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="error">

                            <?php echo e($message); ?>


                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                <!-- ================= PASSWORD ================= -->

                <div class="form-group">

                    <label for="password">

                        <i class="fa-solid fa-lock"></i>

                        Password

                    </label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Masukkan password"
                        autocomplete="new-password"
                        required>

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="error">

                            <?php echo e($message); ?>


                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                <!-- ================= INGAT SAYA ================= -->

                <div class="login-options">

                    <label class="remember">

                        <input
                            type="checkbox"
                            name="remember">

                        <span>
                            Ingat saya
                        </span>

                    </label>

                </div>


                <!-- ================= TOMBOL LOGIN ================= -->

                <button
                    type="submit"
                    class="btn-login">

                    <i class="fa-solid fa-right-to-bracket"></i>

                    Masuk

                </button>


            </form>

        </div>

    </section>


    <!-- ================= KEMBALI KE WEBSITE ================= -->

    <a
        href="<?php echo e(route('beranda')); ?>"
        class="back-to-website">

        <i class="fa-solid fa-arrow-left"></i>

        Kembali ke Website

    </a>


</div>

</body>

</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/login.blade.php ENDPATH**/ ?>