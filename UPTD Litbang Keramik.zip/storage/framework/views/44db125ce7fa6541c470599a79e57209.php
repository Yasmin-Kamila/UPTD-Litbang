<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Profil - UPTD Litbang Keramik</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/profil.css')); ?>">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

<div class="website">

    <!-- ================= NAVBAR ================= -->
    <header class="navbar">

        <div class="brand">

            <div class="logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
            </div>

            <div class="brand-name">
                <strong>UPTD LITBANG</strong>
                <span>PLERED PURWAKARTA</span>
            </div>

        </div>

        <nav class="menu" id="menu">

            <a href="<?php echo e(route('beranda')); ?>">
                Beranda
            </a>

            <a href="<?php echo e(route('profil')); ?>" class="active">
                Profil
            </a>

            <a href="<?php echo e(route('layanan')); ?>">
                Layanan
            </a>

            <a href="<?php echo e(route('galeri')); ?>">
                Galeri
            </a>

            <a href="<?php echo e(route('artikel')); ?>">
                Artikel
            </a>

            <a href="<?php echo e(route('organigram')); ?>">
                Organigram
            </a>

        </nav>

        <!-- Hamburger -->
        <button class="menu-toggle" onclick="toggleMenu()">
            <i class="fa-solid fa-bars"></i>
        </button>

    </header>


    <!-- =========================
         PROFIL
    ========================== -->
    <main class="content">

        <section class="profile-top">

            <!-- KIRI -->
            <div class="profile-text">

                <h1>PROFIL</h1>

                <h2>
                    <?php echo e($profil->judul ?? 'UPTD LITBANG KERAMIK'); ?>

                </h2>

                <p>
                    <?php echo e($data['deskripsi'] ?? ''); ?>

                </p>


                <!-- SEJARAH -->
                <div class="history">

                    <h2>SEJARAH</h2>

                    <div class="history-line"></div>

                    <p>
                        <?php echo nl2br(e($data['sejarah'] ?? '')); ?>

                    </p>

                </div>

            </div>


            <!-- KANAN / FOTO -->
            <div class="profile-image">

                <?php if($profil && $profil->gambar): ?>

                    <img
                        src="<?php echo e(asset('storage/' . $profil->gambar)); ?>"
                        alt="<?php echo e($profil->judul); ?>"
                    >

                <?php else: ?>

                    <img
                        src="<?php echo e(asset('img/gedung.jpg')); ?>"
                        alt="Gedung UPTD Litbang Keramik"
                    >

                <?php endif; ?>

            </div>

        </section>


        <!-- =========================
             VISI MISI
        ========================== -->
        <section class="vision-mission">

            <h2>VISI &amp; MISI</h2>

            <div class="title-line"></div>


            <div class="vision-mission-content">

                <!-- VISI -->
                <div class="vision">

                    <h3>VISI:</h3>

                    <p>
                        <?php echo nl2br(e($data['visi'] ?? '')); ?>

                    </p>

                </div>


                <!-- MISI -->
                <div class="mission">

                    <h3>MISI:</h3>

                    <ol>

                        <?php $__currentLoopData = preg_split('/\r\n|\r|\n/', $data['misi'] ?? ''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if(trim($misi) !== ''): ?>
                                <li><?php echo e($misi); ?></li>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ol>

                </div>

            </div>

        </section>

    </main>


    <!-- =========================
         FOOTER
    ========================== -->
    <footer class="footer">

        <div class="footer-main">

            <!-- BRAND -->
            <div class="footer-brand">

                <div class="footer-logo">

                    <div class="footer-logo-circle"></div>

                    <div>
                        <strong>UPTD LITBANG</strong>
                        <span>PLERED PURWAKARTA</span>
                    </div>

                </div>

            </div>


            <!-- DESKRIPSI -->
            <div class="footer-description">

                <p>
                    Mengembangkan potensi keramik lokal<br>
                    melalui pelatihan, pembinaan, dan<br>
                    inovasi untuk kemajuan bersama
                </p>

                <div class="footer-social">

                    <a href="#">
                        <i class="fa-brands fa-instagram"></i>
                    </a>

                    <a href="#">
                        <i class="fa-brands fa-youtube"></i>
                    </a>

                    <a href="#">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>

                </div>

            </div>


            <!-- KONTAK -->
            <div class="footer-contact">

                <div class="contact-item">
                    <i class="fa-solid fa-phone"></i>
                    <span>0877-7983-0642</span>
                </div>

                <div class="contact-item">
                    <i class="fa-regular fa-envelope"></i>
                    <span>@gmail.com</span>
                </div>

                <div class="contact-item">

                    <i class="fa-regular fa-clock"></i>

                    <div>
                        <span>Senin - Jumat</span>
                        <small>08.00 - 16.00 WIB</small>
                    </div>

                </div>

            </div>


            <!-- ALAMAT -->
            <div class="footer-address">

                <div class="address-title">

                    <i class="fa-solid fa-location-dot"></i>

                    <span>Alamat</span>

                </div>

                <p>
                    Jl. Raya Plered No.12B, Anjun, Kec. Plered,<br>
                    Kab. Purwakarta, Jawa Barat 41162
                </p>

            </div>

        </div>


        <!-- COPYRIGHT -->
        <div class="footer-bottom">

            <p>
                © 2026 UPTD Litbang Keramik Plered Purwakarta. All Rights Reserved.
            </p>

        </div>

    </footer>

</div>


<!-- ================= JAVASCRIPT ================= -->
<script>
    function toggleMenu() {
        const menu = document.getElementById("menu");
        menu.classList.toggle("show");
    }
</script>

</body>
</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/profil.blade.php ENDPATH**/ ?>