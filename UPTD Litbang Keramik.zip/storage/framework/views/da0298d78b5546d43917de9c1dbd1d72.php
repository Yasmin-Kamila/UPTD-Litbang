<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Detail Artikel - UPTD Litbang Keramik</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/artikel-detail.css')); ?>">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

<div class="website">

    <!-- ================= NAVBAR ================= -->

    <header class="navbar">

        <div class="brand">

            <div class="logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
            </div>

            <div class="brand-name">
                <strong>UPTD LITBANG</strong>
                <span>PLERED PURWAKARTA</span>
            </div>

        </div>

        <nav class="menu" id="menu">

            <a href="<?php echo e(route('beranda')); ?>">
                Beranda
            </a>

            <a href="<?php echo e(route('profil')); ?>">
                Profil
            </a>

            <a href="<?php echo e(route('layanan')); ?>">
                Layanan
            </a>

            <a href="<?php echo e(route('galeri')); ?>">
                Galeri
            </a>

            <a href="<?php echo e(route('artikel')); ?>" class="active">
                Artikel
            </a>

            <a href="<?php echo e(route('organigram')); ?>">
                Organigram
            </a>
            
        </nav>

        <!-- HAMBURGER -->

        <button class="menu-toggle"
                type="button"
                onclick="toggleMenu()">

            <i class="fa-solid fa-bars"></i>

        </button>

    </header>


    <!-- ================= DETAIL ARTIKEL ================= -->

    <main class="content">

        <h1 class="page-title">
            ARTIKEL
        </h1>

        <section class="article-box">

            <!-- GAMBAR -->

            <div class="article-image">

                <?php if($artikel->gambar): ?>

                    <img
                        src="<?php echo e(asset('storage/' . $artikel->gambar)); ?>"
                        alt="<?php echo e($artikel->judul); ?>">

                <?php else: ?>

                    <img
                        src="<?php echo e(asset('images/kegiatan1.jpg')); ?>"
                        alt="<?php echo e($artikel->judul); ?>">

                <?php endif; ?>

            </div>


            <!-- ================= INFORMASI ARTIKEL ================= -->

            <div class="article-detail-content">

                <!-- JUDUL -->

                <h2 class="article-title">
                    <?php echo e($artikel->judul); ?>

                </h2>


                <!-- TANGGAL -->

                <?php if($artikel->tanggal): ?>

                    <div class="article-date">

                        <?php echo e(\Carbon\Carbon::parse($artikel->tanggal)->format('d F Y')); ?>


                    </div>

                <?php endif; ?>


                <!-- ISI ARTIKEL -->

                <div class="article-description">

                    <p>
                        <?php echo e($artikel->isi); ?>

                    </p>

                </div>

            </div>


            <!-- ================= KEMBALI ================= -->

            <div class="back-button">

                <a href="<?php echo e(route('artikel')); ?>">
                    Kembali ke Artikel
                </a>

            </div>

        </section>

    </main>


    <!-- ================= FOOTER ================= -->

    <footer class="footer">

        <div class="footer-main">

            <!-- BRAND -->

            <div class="footer-brand">

                <div class="footer-logo">

                    <img
                        src="<?php echo e(asset('images/logo.png')); ?>"
                        alt="Logo">

                    <div>

                        <strong>
                            UPTD LITBANG
                        </strong>

                        <span>
                            PLERED PURWAKARTA
                        </span>

                    </div>

                </div>

            </div>


            <!-- DESKRIPSI -->

            <div class="footer-description">

                <p>
                    Mengembangkan potensi keramik lokal
                    melalui pelatihan, pembinaan, dan
                    inovasi untuk kemajuan bersama
                </p>

                <div class="footer-social">

                    <a href="https://www.instagram.com/sentrakeramikpurwakarta?stkn=djBjc2N4YzVkenNk">
                        <i class="fa-brands fa-instagram"></i>
                    </a>

                    <a href="https://www.youtube.com/channel/UCZ8i6yGa25uSPrSVXXIZbzw">
                        <i class="fa-brands fa-youtube"></i>
                    </a>

                    <a href="#">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>

                </div>

            </div>


            <!-- KONTAK -->

            <div class="footer-contact">

                <div class="contact-item">

                    <i class="fa-solid fa-phone"></i>

                    <span>
                        0877-7983-0642
                    </span>

                </div>

                <div class="contact-item">

                    <i class="fa-regular fa-envelope"></i>

                    <span>
                        @gmail.com
                    </span>

                </div>

                <div class="contact-item">

                    <i class="fa-regular fa-clock"></i>

                    <div>

                        <span>
                            Senin - Jumat
                        </span>

                        <small>
                            08.00 - 16.00 WIB
                        </small>

                    </div>

                </div>

            </div>


            <!-- ALAMAT -->

            <div class="footer-address">

                <div class="address-title">

                    <i class="fa-solid fa-location-dot"></i>

                    <span>
                        Alamat
                    </span>

                </div>

                <p>
                    Jl. Raya Plered No.12B, Anjun, Kec. Plered,
                    Kab. Purwakarta, Jawa Barat 41162
                </p>

            </div>

        </div>


        <!-- COPYRIGHT -->

        <div class="footer-bottom">

            <p>
                © 2026 UPTD Litbang Keramik Plered Purwakarta.
                All Rights Reserved.
            </p>

        </div>

    </footer>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

    function toggleMenu() {

        const menu = document.getElementById("menu");

        menu.classList.toggle("show");

    }

</script>

</body>

</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/artikel-detail.blade.php ENDPATH**/ ?>