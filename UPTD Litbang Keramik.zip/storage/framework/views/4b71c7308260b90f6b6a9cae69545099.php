<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Organigram - UPTD Litbang Plered</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/organigram.css')); ?>">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

<div class="website">

    <!-- ================= NAVBAR ================= -->

    <header class="navbar">

        <div class="brand">

            <div class="logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
            </div>

            <div class="brand-name">
                <strong>UPTD LITBANG</strong>
                <span>PLERED PURWAKARTA</span>
            </div>

        </div>


        <!-- MENU -->

        <nav class="menu" id="menu">

            <a href="<?php echo e(route('beranda')); ?>">
                Beranda
            </a>

            <a href="<?php echo e(route('profil')); ?>">
                Profil
            </a>

            <a href="<?php echo e(route('layanan')); ?>">
                Layanan
            </a>

            <a href="<?php echo e(route('galeri')); ?>">
                Galeri
            </a>

            <a href="<?php echo e(route('artikel')); ?>">
                Artikel
            </a>

            <a href="<?php echo e(route('organigram')); ?>" class="active">
                Organigram
            </a>

        </nav>


        <!-- HAMBURGER -->

        <button class="menu-toggle" onclick="toggleMenu()">
            <i class="fa-solid fa-bars"></i>
        </button>

    </header>


    <!-- ================= KONTEN ================= -->

    <main class="content">

        <h1 class="page-title">
            STRUKTUR ORGANISASI
        </h1>


        <section class="organization">


            <?php if($organigram->count() > 0): ?>


                <!-- ================= KEPALA UPTD ================= -->

                <div class="org-top">

                    <div class="person-card">

                        <div class="person-photo">

                            <?php if($organigram[0]->gambar): ?>

                                <img src="<?php echo e(asset('storage/' . $organigram[0]->gambar)); ?>"
                                     alt="<?php echo e($organigram[0]->nama); ?>">

                            <?php else: ?>

                                <i class="fa-solid fa-user"></i>

                            <?php endif; ?>

                        </div>


                        <div class="person-info">

                            <h3>
                                <?php echo e($organigram[0]->nama); ?>

                            </h3>

                            <p>
                                <?php echo e($organigram[0]->jabatan); ?>

                            </p>

                        </div>

                    </div>

                </div>


                <!-- ================= GARIS DARI KEPALA ================= -->

                <?php if($organigram->count() > 1): ?>

                    <div class="line-top"></div>

                <?php endif; ?>


                <!-- ================= LEVEL 2 ================= -->

                <?php if($organigram->count() > 1): ?>

                    <div class="org-middle">

                        <?php $__currentLoopData = $organigram->slice(1, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="person-card">

                                <div class="person-photo">

                                    <?php if($item->gambar): ?>

                                        <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                                             alt="<?php echo e($item->nama); ?>">

                                    <?php else: ?>

                                        <i class="fa-solid fa-user"></i>

                                    <?php endif; ?>

                                </div>


                                <div class="person-info">

                                    <h3>
                                        <?php echo e($item->nama); ?>

                                    </h3>

                                    <p>
                                        <?php echo e($item->jabatan); ?>

                                    </p>

                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>


                <!-- ================= LEVEL 3 ================= -->

                <?php if($organigram->count() > 4): ?>

                    <div class="org-bottom">

                        <?php $__currentLoopData = $organigram->slice(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="person-card">

                                <div class="person-photo">

                                    <?php if($item->gambar): ?>

                                        <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                                             alt="<?php echo e($item->nama); ?>">

                                    <?php else: ?>

                                        <i class="fa-solid fa-user"></i>

                                    <?php endif; ?>

                                </div>


                                <div class="person-info">

                                    <h3>
                                        <?php echo e($item->nama); ?>

                                    </h3>

                                    <p>
                                        <?php echo e($item->jabatan); ?>

                                    </p>

                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>


            <?php else: ?>


                <!-- ================= DATA KOSONG ================= -->

                <div class="empty-organigram">

                    <i class="fa-solid fa-sitemap"></i>

                    <p>
                        Belum ada data struktur organisasi.
                    </p>

                </div>


            <?php endif; ?>

        </section>

    </main>


    <!-- ================= FOOTER ================= -->

    <footer class="footer">

        <div class="footer-content">


            <!-- BRAND -->

            <div class="footer-brand">

                <div class="footer-logo">

                    <img src="<?php echo e(asset('images/logo.png')); ?>"
                         alt="Logo UPTD Litbang Keramik">

                </div>

                <div>

                    <h3>
                        UPTD LITBANG
                    </h3>

                    <span>
                        PLERED PURWAKARTA
                    </span>

                </div>

            </div>


            <!-- DESKRIPSI -->

            <div class="footer-description">

                <p>
                    Mengembangkan potensi keramik lokal
                    melalui pelatihan, pembinaan, dan
                    inovasi untuk kemajuan bersama.
                </p>


                <div class="footer-social">

                    <a href="https://www.instagram.com/sentrakeramikpurwakarta?stkn=djBjc2N4YzVkenNk"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-instagram"></i>

                    </a>


                    <a href="https://www.youtube.com/channel/UCZ8i6yGa25uSPrSVXXIZbzw"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-youtube"></i>

                    </a>


                    <a href="#">

                        <i class="fa-brands fa-facebook-f"></i>

                    </a>

                </div>

            </div>


            <!-- KONTAK -->

            <div class="footer-contact">

                <p>

                    <i class="fa-solid fa-phone"></i>

                    0877-7983-0642

                </p>


                <p>

                    <i class="fa-regular fa-envelope"></i>

                    @gmail.com

                </p>


                <p>

                    <i class="fa-regular fa-clock"></i>

                    Senin - Jumat

                    <small>
                        08.00 - 16.00 WIB
                    </small>

                </p>

            </div>


            <!-- ALAMAT -->

            <div class="footer-address">

                <p>

                    <i class="fa-solid fa-location-dot"></i>

                    Alamat

                </p>


                <p>

                    Jl. Raya Plered No.12B, Anjun, Kec. Plered,
                    Kab. Purwakarta, Jawa Barat 41162

                </p>

            </div>

        </div>


        <!-- COPYRIGHT -->

        <div class="copyright">

            © 2026 UPTD Litbang Keramik Plered Purwakarta.
            All Rights Reserved.

        </div>

    </footer>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

function toggleMenu() {

    const menu = document.getElementById("menu");

    menu.classList.toggle("show");

}

</script>

</body>
</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/organigram.blade.php ENDPATH**/ ?>