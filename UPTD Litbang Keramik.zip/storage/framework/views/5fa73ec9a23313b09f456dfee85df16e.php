<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Galeri - UPTD Litbang Keramik</title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet"
          href="<?php echo e(asset('css/galeri.css')); ?>">
</head>

<body>

<div class="website">

    <!-- ================= NAVBAR ================= -->
    <header class="navbar">

        <div class="brand">

            <div class="logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
            </div>

            <div class="brand-name">
                <strong>UPTD LITBANG</strong>
                <span>PLERED PURWAKARTA</span>
            </div>

        </div>

        <nav class="menu" id="menu">

            <a href="<?php echo e(route('beranda')); ?>">
                Beranda
            </a>

            <a href="<?php echo e(route('profil')); ?>">
                Profil
            </a>

            <a href="<?php echo e(route('layanan')); ?>">
                Layanan
            </a>

            <a href="<?php echo e(route('galeri')); ?>" class="active">
                Galeri
            </a>

            <a href="<?php echo e(route('artikel')); ?>">
                Artikel
            </a>

            <a href="<?php echo e(route('organigram')); ?>">
                Organigram
            </a>
            
        </nav>

        <!-- Hamburger -->
        <button class="menu-toggle" onclick="toggleMenu()">
            <i class="fa-solid fa-bars"></i>
        </button>

    </header>


    <!-- ================= GALERI ================= -->
    <main class="galeri-page">

        <h1>GALERI KEGIATAN</h1>

        <section class="gallery-grid">

            <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <article class="gallery-card">

                    <div class="gallery-image">
                        <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                             alt="<?php echo e($item->judul); ?>">
                    </div>

                    <div class="gallery-info">

                        <h2><?php echo e($item->judul); ?></h2>

                        <p>
                            <i class="fa-regular fa-calendar-days"></i>
                            <?php echo e($item->tanggal); ?>

                        </p>

                    </div>

                </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </section>

    </main>


    <!-- ================= FOOTER ================= -->

    <footer class="footer">

        <div class="footer-content">


            <!-- BRAND -->

            <div class="footer-brand">

                <div class="footer-logo">

                    <img src="<?php echo e(asset('images/logo.png')); ?>"
                         alt="Logo UPTD Litbang Keramik">

                </div>

                <div>

                    <h3>
                        UPTD LITBANG
                    </h3>

                    <span>
                        PLERED PURWAKARTA
                    </span>

                </div>

            </div>


            <!-- DESKRIPSI -->

            <div class="footer-description">

                <p>
                    Mengembangkan potensi keramik lokal
                    melalui pelatihan, pembinaan, dan
                    inovasi untuk kemajuan bersama.
                </p>


                <div class="footer-social">

                    <a href="https://www.instagram.com/sentrakeramikpurwakarta?stkn=djBjc2N4YzVkenNk"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-instagram"></i>

                    </a>


                    <a href="https://www.youtube.com/channel/UCZ8i6yGa25uSPrSVXXIZbzw"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-youtube"></i>

                    </a>


                    <a href="#">

                        <i class="fa-brands fa-facebook-f"></i>

                    </a>

                </div>

            </div>


            <!-- KONTAK -->

            <div class="footer-contact">

                <p>

                    <i class="fa-solid fa-phone"></i>

                    0877-7983-0642

                </p>


                <p>

                    <i class="fa-regular fa-envelope"></i>

                    @gmail.com

                </p>


                <p>

                    <i class="fa-regular fa-clock"></i>

                    Senin - Jumat

                    <small>
                        08.00 - 16.00 WIB
                    </small>

                </p>

            </div>


            <!-- ALAMAT -->

            <div class="footer-address">

                <p>

                    <i class="fa-solid fa-location-dot"></i>

                    Alamat

                </p>


                <p>

                    Jl. Raya Plered No.12B, Anjun, Kec. Plered,
                    Kab. Purwakarta, Jawa Barat 41162

                </p>

            </div>

        </div>


        <!-- COPYRIGHT -->

        <div class="copyright">

            © 2026 UPTD Litbang Keramik Plered Purwakarta.
            All Rights Reserved.

        </div>

    </footer>

</div>


    <!-- ================= JAVASCRIPT ================= -->
    <script>
        function toggleMenu() {
            const menu = document.getElementById('menu');
            menu.classList.toggle('show');
        }
    </script>

</div>

</body>
</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/galeri.blade.php ENDPATH**/ ?>