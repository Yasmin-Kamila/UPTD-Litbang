<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Beranda - UPTD Litbang Plered</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/beranda.css')); ?>">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

<div class="website">

    <!-- ================= NAVBAR ================= -->

    <header class="navbar">

        <div class="brand">

            <div class="logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>"
                     alt="Logo UPTD Litbang Keramik">
            </div>

            <div class="brand-name">
                <strong>UPTD LITBANG</strong>
                <span>PLERED PURWAKARTA</span>
            </div>

        </div>


        <nav class="menu" id="menu">

            <a href="<?php echo e(route('beranda')); ?>" class="active">
                Beranda
            </a>

            <a href="<?php echo e(route('profil')); ?>">
                Profil
            </a>

            <a href="<?php echo e(route('layanan')); ?>">
                Layanan
            </a>

            <a href="<?php echo e(route('galeri')); ?>">
                Galeri
            </a>

            <a href="<?php echo e(route('artikel')); ?>">
                Artikel
            </a>

            <a href="<?php echo e(route('organigram')); ?>">
                Organigram
            </a>

        </nav>


        <!-- Hamburger -->

        <button class="menu-toggle" type="button" onclick="toggleMenu()">
            <i class="fa-solid fa-bars"></i>
        </button>

    </header>


    <!-- ================= HERO ================= -->

    <section class="hero">

        <div class="hero-content">

            <div class="hero-text">

                <p class="welcome">
                    Selamat Datang di Website
                </p>

                <h1>
                    UPTD LITBANG KERAMIK
                </h1>

                <h2>
                    PLERED PURWAKARTA
                </h2>

                <p class="description">
                    UPTD Litbang Keramik Plered merupakan unit pelaksana teknis
                    yang bergerak dalam penelitian, pengembangan, pembinaan dan
                    pelayanan teknologi keramik bagi masyarakat dan pelaku usaha.
                </p>

                <a href="<?php echo e(route('profil')); ?>" class="hero-button">
                    Profil Kami
                </a>

            </div>


            <div class="hero-image">

                <img src="<?php echo e(asset('images/kantor.jpg')); ?>"
                     alt="Gedung UPTD Litbang Keramik Plered">

            </div>

        </div>

    </section>


    <!-- ================= LAYANAN ================= -->

    <section class="layanan">

        <h2 class="section-title">
            Layanan Kami
        </h2>


        <div class="layanan-list">

            <?php $__empty_1 = true; $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="layanan-card <?php echo e($loop->even ? 'darker' : ''); ?>">

                    <div class="layanan-icon">

                        <?php if($loop->iteration == 1): ?>
                            💼
                        <?php elseif($loop->iteration == 2): ?>
                            🚐
                        <?php elseif($loop->iteration == 3): ?>
                            ⚖️
                        <?php elseif($loop->iteration == 4): ?>
                            📢
                        <?php else: ?>
                            💼
                        <?php endif; ?>

                    </div>


                    <h3>
                        <?php echo e($item->judul); ?>

                    </h3>


                    <p>
                        <?php echo e($item->deskripsi); ?>

                    </p>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div class="data-kosong">
                    <i class="fa-solid fa-circle-info"></i>
                    <p>Belum ada layanan yang tersedia.</p>
                </div>

            <?php endif; ?>

        </div>


        <div class="layanan-button-area">

            <a href="<?php echo e(route('layanan')); ?>">
                Lihat Selengkapnya
            </a>

        </div>

    </section>


    <!-- ================= TERBARU & DOKUMENTASI ================= -->

    <section class="terbaru">

        <div class="terbaru-content">


            <!-- ================= TERBARU DARI KAMI ================= -->

            <div class="terbaru-kiri">

                <h2>
                    Terbaru dari Kami
                </h2>


                <div class="artikel-mini">

                    <?php $__empty_1 = true; $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <a href="<?php echo e(route('artikel.detail', $artikel->id_artikel)); ?>"
                           class="artikel-mini-card">

                            <div class="mini-image">

                                <?php if($artikel->gambar): ?>

                                    <img src="<?php echo e(asset('storage/' . $artikel->gambar)); ?>"
                                         alt="<?php echo e($artikel->judul); ?>">

                                <?php else: ?>

                                    <img src="<?php echo e(asset('images/kegiatan1.jpg')); ?>"
                                         alt="<?php echo e($artikel->judul); ?>">

                                <?php endif; ?>

                            </div>


                            <div class="mini-info">

                                <h3>
                                    <?php echo e($artikel->judul); ?>

                                </h3>

                                <p>
                                    <?php echo e(\Illuminate\Support\Str::limit(strip_tags($artikel->isi), 100)); ?>

                                </p>

                                <span class="baca-artikel">
                                    Baca Selengkapnya →
                                </span>

                            </div>

                        </a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <div class="data-kosong artikel-kosong">
                            <i class="fa-solid fa-newspaper"></i>
                            <p>Belum ada artikel terbaru.</p>
                        </div>

                    <?php endif; ?>

                </div>

            </div>


            <!-- ================= DOKUMENTASI ================= -->

            <div class="dokumentasi">

                <h2>
                    Dokumentasi Kegiatan
                </h2>


                <div class="dokumentasi-grid">

                    <?php $__empty_1 = true; $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                             alt="<?php echo e($item->judul); ?>">

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <div class="data-kosong galeri-kosong">
                            <i class="fa-solid fa-image"></i>
                            <p>Belum ada dokumentasi kegiatan.</p>
                        </div>

                    <?php endif; ?>

                </div>


                <div class="selengkapnya-area">

                    <a href="<?php echo e(route('galeri')); ?>">
                        Lihat Selengkapnya
                    </a>

                </div>

            </div>

        </div>

    </section>


    <!-- ================= FOOTER ================= -->

    <footer class="footer">

        <div class="footer-content">


            <!-- BRAND -->

            <div class="footer-brand">

                <div class="footer-logo">

                    <img src="<?php echo e(asset('images/logo.png')); ?>"
                         alt="Logo UPTD Litbang Keramik">

                </div>

                <div>

                    <h3>
                        UPTD LITBANG
                    </h3>

                    <span>
                        PLERED PURWAKARTA
                    </span>

                </div>

            </div>


            <!-- DESKRIPSI -->

            <div class="footer-description">

                <p>
                    Mengembangkan potensi keramik lokal
                    melalui pelatihan, pembinaan, dan
                    inovasi untuk kemajuan bersama.
                </p>


                <div class="footer-social">

                    <a href="https://www.instagram.com/sentrakeramikpurwakarta?stkn=djBjc2N4YzVkenNk"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-instagram"></i>

                    </a>


                    <a href="https://www.youtube.com/channel/UCZ8i6yGa25uSPrSVXXIZbzw"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-youtube"></i>

                    </a>


                    <a href="#">

                        <i class="fa-brands fa-facebook-f"></i>

                    </a>

                </div>

            </div>


            <!-- KONTAK -->

            <div class="footer-contact">

                <p>

                    <i class="fa-solid fa-phone"></i>

                    0877-7983-0642

                </p>


                <p>

                    <i class="fa-regular fa-envelope"></i>

                    @gmail.com

                </p>


                <p>

                    <i class="fa-regular fa-clock"></i>

                    Senin - Jumat

                    <small>
                        08.00 - 16.00 WIB
                    </small>

                </p>

            </div>


            <!-- ALAMAT -->

            <div class="footer-address">

                <p>

                    <i class="fa-solid fa-location-dot"></i>

                    Alamat

                </p>


                <p>

                    Jl. Raya Plered No.12B, Anjun, Kec. Plered,
                    Kab. Purwakarta, Jawa Barat 41162

                </p>

            </div>

        </div>


        <!-- COPYRIGHT -->

        <div class="copyright">

            © 2026 UPTD Litbang Keramik Plered Purwakarta.
            All Rights Reserved.

        </div>

    </footer>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

    function toggleMenu() {

        const menu = document.getElementById("menu");

        menu.classList.toggle("show");

    }

</script>


</body>
</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/beranda.blade.php ENDPATH**/ ?>