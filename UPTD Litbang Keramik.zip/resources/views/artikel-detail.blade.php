<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Detail Artikel - UPTD Litbang Keramik</title>

    <link rel="stylesheet" href="{{ asset('css/artikel-detail.css') }}">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

<div class="website">

    <!-- ================= NAVBAR ================= -->

    <header class="navbar">

        <div class="brand">

            <div class="logo">
                <img src="{{ asset('images/logo.png') }}" alt="Logo">
            </div>

            <div class="brand-name">
                <strong>UPTD LITBANG</strong>
                <span>PLERED PURWAKARTA</span>
            </div>

        </div>

        <nav class="menu" id="menu">

            <a href="{{ route('beranda') }}">
                Beranda
            </a>

            <a href="{{ route('profil') }}">
                Profil
            </a>

            <a href="{{ route('layanan') }}">
                Layanan
            </a>

            <a href="{{ route('galeri') }}">
                Galeri
            </a>

            <a href="{{ route('artikel') }}" class="active">
                Artikel
            </a>

            <a href="{{ route('organigram') }}">
                Organigram
            </a>
            
        </nav>

        <!-- HAMBURGER -->

        <button class="menu-toggle"
                type="button"
                onclick="toggleMenu()">

            <i class="fa-solid fa-bars"></i>

        </button>

    </header>


    <!-- ================= DETAIL ARTIKEL ================= -->

    <main class="content">

        <h1 class="page-title">
            ARTIKEL
        </h1>

        <section class="article-box">

            <!-- GAMBAR -->

            <div class="article-image">

                @if ($artikel->gambar)

                    <img
                        src="{{ asset('storage/' . $artikel->gambar) }}"
                        alt="{{ $artikel->judul }}">

                @else

                    <img
                        src="{{ asset('images/kegiatan1.jpg') }}"
                        alt="{{ $artikel->judul }}">

                @endif

            </div>


            <!-- ================= INFORMASI ARTIKEL ================= -->

            <div class="article-detail-content">

                <!-- JUDUL -->

                <h2 class="article-title">
                    {{ $artikel->judul }}
                </h2>


                <!-- TANGGAL -->

                @if ($artikel->tanggal)

                    <div class="article-date">

                        {{ \Carbon\Carbon::parse($artikel->tanggal)->format('d F Y') }}

                    </div>

                @endif


                <!-- ISI ARTIKEL -->

                <div class="article-description">

                    <p>
                        {{ $artikel->isi }}
                    </p>

                </div>

            </div>


            <!-- ================= KEMBALI ================= -->

            <div class="back-button">

                <a href="{{ route('artikel') }}">
                    Kembali ke Artikel
                </a>

            </div>

        </section>

    </main>


    <!-- ================= FOOTER ================= -->

    <footer class="footer">

        <div class="footer-content">


            <!-- BRAND -->

            <div class="footer-brand">

                <div class="footer-logo">

                    <img src="{{ asset('images/logo.png') }}"
                         alt="Logo UPTD Litbang Keramik">

                </div>

                <div>

                    <h3>
                        UPTD LITBANG
                    </h3>

                    <span>
                        PLERED PURWAKARTA
                    </span>

                </div>

            </div>


            <!-- DESKRIPSI -->

            <div class="footer-description">

                <p>
                    Mengembangkan potensi keramik lokal
                    melalui pelatihan, pembinaan, dan
                    inovasi untuk kemajuan bersama.
                </p>


                <div class="footer-social">

                    <a href="https://www.instagram.com/sentrakeramikpurwakarta?stkn=djBjc2N4YzVkenNk"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-instagram"></i>

                    </a>


                    <a href="https://www.youtube.com/channel/UCZ8i6yGa25uSPrSVXXIZbzw"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-youtube"></i>

                    </a>


                    <a href="#">

                        <i class="fa-brands fa-facebook-f"></i>

                    </a>

                </div>

            </div>


            <!-- KONTAK -->

            <div class="footer-contact">

                <p>

                    <i class="fa-solid fa-phone"></i>

                    0877-7983-0642

                </p>


                <p>

                    <i class="fa-regular fa-envelope"></i>

                    @gmail.com

                </p>


                <p>

                    <i class="fa-regular fa-clock"></i>

                    Senin - Jumat

                    <small>
                        08.00 - 16.00 WIB
                    </small>

                </p>

            </div>


            <!-- ALAMAT -->

            <div class="footer-address">

                <p>

                    <i class="fa-solid fa-location-dot"></i>

                    Alamat

                </p>


                <p>

                    Jl. Raya Plered No.12B, Anjun, Kec. Plered,
                    Kab. Purwakarta, Jawa Barat 41162

                </p>

            </div>

        </div>


        <!-- COPYRIGHT -->

        <div class="copyright">

            © 2026 UPTD Litbang Keramik Plered Purwakarta.
            All Rights Reserved.

        </div>

    </footer>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

    function toggleMenu() {

        const menu = document.getElementById("menu");

        menu.classList.toggle("show");

    }

</script>

</body>

</html>