<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Artikel</title>

    <link rel="stylesheet"
          href="{{ asset('css/artikel.css') }}">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

</head>


<body>

<div class="website">


    <!-- ================= NAVBAR ================= -->

    <header class="navbar">


        <div class="brand">


            <div class="logo">

                <img src="{{ asset('images/logo.png') }}"
                     alt="Logo">

            </div>


            <div class="brand-name">

                <strong>
                    UPTD LITBANG
                </strong>

                <span>
                    PLERED PURWAKARTA
                </span>

            </div>


        </div>



        <nav class="menu" id="menu">


            <a href="{{ route('beranda') }}">
                Beranda
            </a>


            <a href="{{ route('profil') }}">
                Profil
            </a>


            <a href="{{ route('layanan') }}">
                Layanan
            </a>


            <a href="{{ route('galeri') }}">
                Galeri
            </a>


            <a href="{{ route('artikel') }}"
               class="active">
                Artikel
            </a>


            <a href="{{ route('organigram') }}">
                Organigram
            </a>


        </nav>



        <!-- HAMBURGER -->

        <button class="menu-toggle"
                type="button"
                onclick="toggleMenu()">

            <i class="fa-solid fa-bars"></i>

        </button>


    </header>



    <!-- ================= ARTIKEL ================= -->

    <main class="artikel">


        <h1>
            ARTIKEL
        </h1>



        <div class="artikel-grid">


            <!-- ================= DATA ARTIKEL ================= -->

            @forelse ($artikel as $item)


                <article class="artikel-card">


                    <!-- GAMBAR -->

                    <div class="artikel-image">


                        @if ($item->gambar)

                            <img
                                src="{{ asset('storage/' . $item->gambar) }}"
                                alt="{{ $item->judul }}">

                        @else

                            <img
                                src="{{ asset('images/kegiatan1.jpg') }}"
                                alt="{{ $item->judul }}">

                        @endif


                    </div>



                    <!-- JUDUL -->

                    <h2>

                        {{ $item->judul }}

                    </h2>



                    <!-- TANGGAL -->

                    <div class="tanggal">


                        @if ($item->tanggal)

                            {{ \Carbon\Carbon::parse($item->tanggal)->format('d F Y') }}

                        @endif


                    </div>



                    <!-- ISI ARTIKEL -->

                    <p class="artikel-isi">

                        {{ $item->isi }}

                    </p>



                    <!-- TOMBOL SELENGKAPNYA -->

                    <a href="{{ route('artikel.detail', $item->id_artikel) }}"
                       class="btn-selengkapnya">

                        Selengkapnya

                        <i class="fa-solid fa-arrow-right"></i>

                    </a>


                </article>


            <!-- ================= JIKA KOSONG ================= -->

            @empty


                <div class="artikel-kosong">


                    <i class="fa-solid fa-circle-info"></i>


                    <p>

                        Belum ada artikel yang tersedia.

                    </p>


                </div>


            @endforelse


        </div>


    </main>



    <!-- ================= FOOTER ================= -->

    <footer class="footer">


        <div class="footer-content">


            <!-- BRAND -->

            <div class="footer-brand">


                <div class="footer-logo">

                    <img src="{{ asset('images/logo.png') }}"
                         alt="Logo UPTD Litbang Keramik">

                </div>


                <div>

                    <h3>
                        UPTD LITBANG
                    </h3>

                    <span>
                        PLERED PURWAKARTA
                    </span>

                </div>


            </div>



            <!-- DESKRIPSI -->

            <div class="footer-description">


                <p>

                    Mengembangkan potensi keramik lokal
                    melalui pelatihan, pembinaan, dan
                    inovasi untuk kemajuan bersama.

                </p>



                <div class="footer-social">


                    <a href="https://www.instagram.com/sentrakeramikpurwakarta?stkn=djBjc2N4YzVkenNk"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-instagram"></i>

                    </a>



                    <a href="https://www.youtube.com/channel/UCZ8i6yGa25uSPrSVXXIZbzw"
                       target="_blank"
                       rel="noopener noreferrer">

                        <i class="fa-brands fa-youtube"></i>

                    </a>



                    <a href="#">

                        <i class="fa-brands fa-facebook-f"></i>

                    </a>


                </div>


            </div>



            <!-- KONTAK -->

            <div class="footer-contact">


                <p>

                    <i class="fa-solid fa-phone"></i>

                    0877-7983-0642

                </p>



                <p>

                    <i class="fa-regular fa-envelope"></i>

                    @gmail.com

                </p>



                <p>

                    <i class="fa-regular fa-clock"></i>

                    Senin - Jumat

                    <small>
                        08.00 - 16.00 WIB
                    </small>

                </p>


            </div>



            <!-- ALAMAT -->

            <div class="footer-address">


                <p>

                    <i class="fa-solid fa-location-dot"></i>

                    Alamat

                </p>



                <p>

                    Jl. Raya Plered No.12B, Anjun, Kec. Plered,
                    Kab. Purwakarta, Jawa Barat 41162

                </p>


            </div>


        </div>



        <!-- COPYRIGHT -->

        <div class="copyright">

            © 2026 UPTD Litbang Keramik Plered Purwakarta.
            All Rights Reserved.

        </div>


    </footer>


</div>



<!-- ================= JAVASCRIPT ================= -->

<script>

    function toggleMenu() {

        const menu =
            document.getElementById("menu");

        menu.classList.toggle("show");

    }

</script>


</body>

</html>