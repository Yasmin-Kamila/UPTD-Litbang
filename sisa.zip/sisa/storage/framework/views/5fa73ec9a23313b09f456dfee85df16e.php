<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Galeri - UPTD Litbang Keramik</title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet"
          href="<?php echo e(asset('css/galeri.css')); ?>">
</head>

<body>

<div class="website">

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ================= GALERI ================= -->

    <main class="galeri-page">

        <h1>GALERI KEGIATAN</h1>


        <section class="gallery-grid">

            <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <article class="gallery-card">

                    <div class="gallery-image">

                        <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                             alt="<?php echo e($item->judul); ?>">

                    </div>


                    <div class="gallery-info">

                        <h2>
                            <?php echo e($item->judul); ?>

                        </h2>

                        <p>
                            <i class="fa-regular fa-calendar-days"></i>
                            <?php echo e($item->tanggal); ?>

                        </p>

                    </div>

                </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </section>

    </main>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>
    function toggleMenu() {
        const menu = document.getElementById('menu');
        menu.classList.toggle('show');
    }
</script>

</body>

</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/galeri.blade.php ENDPATH**/ ?>