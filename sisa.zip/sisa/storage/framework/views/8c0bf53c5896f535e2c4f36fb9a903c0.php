<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Layanan - UPTD Litbang Plered</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/layanan.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

<div class="website">

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="content">

        <h1 class="page-title">LAYANAN KAMI</h1>

        <section class="layanan-list">

            <?php $__empty_1 = true; $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="layanan-card">

                    <div class="card-icon">
                        <?php if($loop->iteration == 1): ?>
                            <i class="fa-solid fa-people-group"></i>
                        <?php elseif($loop->iteration == 2): ?>
                            <i class="fa-solid fa-award"></i>
                        <?php elseif($loop->iteration == 3): ?>
                            <i class="fa-solid fa-chalkboard-user"></i>
                        <?php elseif($loop->iteration == 4): ?>
                            <i class="fa-solid fa-bullhorn"></i>
                        <?php elseif($loop->iteration == 5): ?>
                            <i class="fa-solid fa-file-circle-check"></i>
                        <?php elseif($loop->iteration == 6): ?>
                            <i class="fa-solid fa-comments"></i>
                        <?php elseif($loop->iteration == 7): ?>
                            <i class="fa-solid fa-graduation-cap"></i>
                        <?php else: ?>
                            <i class="fa-solid fa-handshake"></i>
                        <?php endif; ?>
                    </div>

                    <h2><?php echo e($item->judul); ?></h2>

                    <div class="dots">
                        <?php echo e($item->deskripsi); ?>

                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div class="empty-layanan">
                    <i class="fa-solid fa-circle-info"></i>
                    <p>Belum ada layanan yang tersedia.</p>
                </div>

            <?php endif; ?>

        </section>

    </main>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<script>
    function toggleMenu() {
        const menu = document.getElementById("menu");
        menu.classList.toggle("show");
    }
</script>

</body>
</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/layanan.blade.php ENDPATH**/ ?>