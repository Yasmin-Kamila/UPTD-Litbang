
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struktur Organisasi</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/organigram.css')); ?>">
</head>
<body>

<div class="website">

    
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="content">

        <h1 class="page-title">STRUKTUR ORGANISASI</h1>

        <section class="organization">

            <?php if($organigram->count() > 0): ?>

                
                <div class="org-row org-row-one">

                    <?php $__currentLoopData = $organigram->slice(0, 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="person-card">

                            <div class="person-photo">

                                <?php if($item->gambar): ?>
                                    <img
                                        src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                                        alt="<?php echo e($item->nama); ?>"
                                    >
                                <?php else: ?>
                                    <div class="no-photo">Foto</div>
                                <?php endif; ?>

                            </div>

                            <div class="person-info">
                                <h3><?php echo e($item->nama); ?></h3>
                                <p><?php echo e($item->jabatan); ?></p>
                            </div>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>


                
                <?php if($organigram->count() > 1): ?>

                    <div class="org-row org-row-two">

                        <?php $__currentLoopData = $organigram->slice(1, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="person-card">

                                <div class="person-photo">

                                    <?php if($item->gambar): ?>
                                        <img
                                            src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                                            alt="<?php echo e($item->nama); ?>"
                                        >
                                    <?php else: ?>
                                        <div class="no-photo">Foto</div>
                                    <?php endif; ?>

                                </div>

                                <div class="person-info">
                                    <h3><?php echo e($item->nama); ?></h3>
                                    <p><?php echo e($item->jabatan); ?></p>
                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>


                
                <?php if($organigram->count() > 3): ?>

                    <div class="org-row org-row-three">

                        <?php $__currentLoopData = $organigram->slice(3, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="person-card">

                                <div class="person-photo">

                                    <?php if($item->gambar): ?>
                                        <img
                                            src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                                            alt="<?php echo e($item->nama); ?>"
                                        >
                                    <?php else: ?>
                                        <div class="no-photo">Foto</div>
                                    <?php endif; ?>

                                </div>

                                <div class="person-info">
                                    <h3><?php echo e($item->nama); ?></h3>
                                    <p><?php echo e($item->jabatan); ?></p>
                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>


                
                <?php if($organigram->count() > 7): ?>

                    <div class="org-row org-row-extra">

                        <?php $__currentLoopData = $organigram->slice(7, 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="person-card">

                                <div class="person-photo">

                                    <?php if($item->gambar): ?>
                                        <img
                                            src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                                            alt="<?php echo e($item->nama); ?>"
                                        >
                                    <?php else: ?>
                                        <div class="no-photo">Foto</div>
                                    <?php endif; ?>

                                </div>

                                <div class="person-info">
                                    <h3><?php echo e($item->nama); ?></h3>
                                    <p><?php echo e($item->jabatan); ?></p>
                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>

            <?php else: ?>

                <p class="empty-message">
                    Data struktur organisasi belum tersedia.
                </p>

            <?php endif; ?>

        </section>

    </main>

    
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

</body>
</html>
<?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/organigram.blade.php ENDPATH**/ ?>