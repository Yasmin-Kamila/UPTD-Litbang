
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e($artikel->judul); ?> - UPTD Litbang Keramik</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/detail-artikel.css')); ?>">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body class="halaman-detail-artikel">

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="detail-artikel">

        <a href="<?php echo e(route('artikel')); ?>" class="tombol-kembali">
            <i class="fa-solid fa-arrow-left"></i>
            Kembali ke Artikel
        </a>

        <article class="detail-container">

            <h1><?php echo e($artikel->judul); ?></h1>

            <div class="detail-tanggal">
                <i class="fa-regular fa-calendar"></i>

                <?php if($artikel->tanggal): ?>
                    <?php echo e(\Carbon\Carbon::parse($artikel->tanggal)->translatedFormat('d F Y')); ?>

                <?php endif; ?>
            </div>

            <?php if($artikel->gambar): ?>
                <div class="detail-gambar">
                    <img
                        src="<?php echo e(asset('storage/' . $artikel->gambar)); ?>"
                        alt="<?php echo e($artikel->judul); ?>">
                </div>
            <?php endif; ?>

            <div class="detail-isi">
                <?php echo nl2br(e($artikel->isi)); ?>

            </div>

        </article>

    </main>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        function toggleMenu() {
            const menu = document.getElementById("menu");

            if (menu) {
                menu.classList.toggle("show");
            }
        }
    </script>

</body>
</html>
<?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/detail-artikel.blade.php ENDPATH**/ ?>