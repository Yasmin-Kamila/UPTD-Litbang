
<link rel="stylesheet" href="<?php echo e(asset('css/layouts/navbar.css')); ?>">

<header class="navbar">

    <div class="brand">
        <div class="logo">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
        </div>

        <div class="brand-name">
            <strong>UPTD LITBANG</strong>
            <span>PLERED PURWAKARTA</span>
        </div>
    </div>

    <nav class="menu" id="menu">

        <a href="<?php echo e(route('beranda')); ?>"
           class="<?php echo e(request()->routeIs('beranda') ? 'active' : ''); ?>">
            Beranda
        </a>

        <a href="<?php echo e(route('profil')); ?>"
           class="<?php echo e(request()->routeIs('profil') ? 'active' : ''); ?>">
            Profil
        </a>

        <a href="<?php echo e(route('layanan')); ?>"
           class="<?php echo e(request()->routeIs('layanan') ? 'active' : ''); ?>">
            Layanan
        </a>

        <a href="<?php echo e(route('galeri')); ?>"
           class="<?php echo e(request()->routeIs('galeri') ? 'active' : ''); ?>">
            Galeri
        </a>

        <a href="<?php echo e(route('artikel')); ?>"
           class="<?php echo e(request()->routeIs('artikel') ? 'active' : ''); ?>">
            Artikel
        </a>

        <a href="<?php echo e(route('organigram')); ?>"
           class="<?php echo e(request()->routeIs('organigram') ? 'active' : ''); ?>">
            Organigram
        </a>

    </nav>

    <button class="menu-toggle"
            type="button"
            onclick="toggleMenu()"
            aria-label="Buka menu">
        ☰
    </button>

</header>

<script>
function toggleMenu() {
    const menu = document.getElementById("menu");

    if (menu) {
        menu.classList.toggle("show");
    }
}
</script>
<?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>