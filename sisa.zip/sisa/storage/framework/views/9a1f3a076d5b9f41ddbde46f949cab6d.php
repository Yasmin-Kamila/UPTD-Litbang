<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Beranda - UPTD Litbang Plered</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/beranda.css')); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

    <div class="website">

        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- ================= HERO ================= -->

        <section class="hero">

            <div class="hero-content">

                <div class="hero-text">

                    <p class="welcome">
                        Selamat Datang di Website
                    </p>

                    <h1>
                        UPTD LITBANG KERAMIK
                    </h1>

                    <h2>
                        PLERED PURWAKARTA
                    </h2>

                    <p class="description">
                        UPTD Litbang Keramik Plered merupakan unit pelaksana teknis
                        yang bergerak dalam penelitian, pengembangan, pembinaan dan
                        pelayanan teknologi keramik bagi masyarakat dan pelaku usaha.
                    </p>

                    <a href="<?php echo e(route('profil')); ?>" class="hero-button">
                        Profil Kami
                    </a>

                </div>


                <div class="hero-image">

                    <img src="<?php echo e(asset('images/UPTD-LITBANG-KERAMIK-PLERED-Copy.webp')); ?>" alt="Gedung UPTD Litbang Keramik">

                </div>

            </div>

        </section>


        <!-- ================= LAYANAN ================= -->

        <section class="layanan">

            <h2 class="section-title">
                Layanan Kami
            </h2>


            <div class="layanan-list">

                <?php $__empty_1 = true; $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="layanan-card <?php echo e($loop->even ? 'darker' : ''); ?>">

                        <div class="layanan-icon">

                            <?php if($loop->iteration == 1): ?>
                                <i class="fa-solid fa-people-group"></i>
                            <?php elseif($loop->iteration == 2): ?>
                                <i class="fa-solid fa-award"></i>
                            <?php elseif($loop->iteration == 3): ?>
                                <i class="fa-solid fa-chalkboard-user"></i>
                            <?php elseif($loop->iteration == 4): ?>
                                <i class="fa-solid fa-bullhorn"></i>
                            <?php elseif($loop->iteration == 5): ?>
                                <i class="fa-solid fa-file-circle-check"></i>
                            <?php elseif($loop->iteration == 6): ?>
                                <i class="fa-solid fa-comments"></i>
                            <?php elseif($loop->iteration == 7): ?>
                                <i class="fa-solid fa-graduation-cap"></i>
                            <?php else: ?>
                                <i class="fa-solid fa-handshake"></i>
                            <?php endif; ?>

                        </div>


                        <h3>
                            <?php echo e($item->judul); ?>

                        </h3>


                        <p>
                            <?php echo e($item->deskripsi); ?>

                        </p>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <div class="data-kosong">
                        <i class="fa-solid fa-circle-info"></i>
                        <p>Belum ada layanan yang tersedia.</p>
                    </div>

                <?php endif; ?>

            </div>


            <div class="layanan-button-area">

                <a href="<?php echo e(route('layanan')); ?>">
                    Lihat Selengkapnya
                </a>

            </div>

        </section>


        <!-- ================= TERBARU & DOKUMENTASI ================= -->

        <section class="terbaru">

            <div class="terbaru-content">


                <!-- ================= TERBARU DARI KAMI ================= -->

                <div class="terbaru-kiri">

                    <h2>
                        Terbaru dari Kami
                    </h2>


                    <div class="artikel-mini">

                        <?php $__empty_1 = true; $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <a href="<?php echo e(route('artikel.detail', $artikel->id_artikel)); ?>" class="artikel-mini-card">

                                <div class="mini-image">

                                    <?php if($artikel->gambar): ?>

                                        <img src="<?php echo e(asset('storage/' . $artikel->gambar)); ?>" alt="<?php echo e($artikel->judul); ?>">

                                    <?php else: ?>

                                        <img src="<?php echo e(asset('images/kegiatan1.jpg')); ?>" alt="<?php echo e($artikel->judul); ?>">

                                    <?php endif; ?>

                                </div>


                                <div class="mini-info">

                                    <h3>
                                        <?php echo e($artikel->judul); ?>

                                    </h3>

                                    <p>
                                        <?php echo e(\Illuminate\Support\Str::limit(strip_tags($artikel->isi), 100)); ?>

                                    </p>

                                    <span class="baca-artikel">
                                        Baca Selengkapnya →
                                    </span>

                                </div>

                            </a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <div class="data-kosong artikel-kosong">
                                <i class="fa-solid fa-newspaper"></i>
                                <p>Belum ada artikel terbaru.</p>
                            </div>

                        <?php endif; ?>

                    </div>

                </div>


                <!-- ================= DOKUMENTASI ================= -->

                <div class="dokumentasi">

                    <h2>
                        Dokumentasi Kegiatan
                    </h2>


                    <div class="dokumentasi-grid">

                        <?php $__empty_1 = true; $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>" alt="<?php echo e($item->judul); ?>">

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <div class="data-kosong galeri-kosong">
                                <i class="fa-solid fa-image"></i>
                                <p>Belum ada dokumentasi kegiatan.</p>
                            </div>

                        <?php endif; ?>

                    </div>


                    <div class="selengkapnya-area">

                        <a href="<?php echo e(route('galeri')); ?>">
                            Lihat Selengkapnya
                        </a>

                    </div>

                </div>

            </div>

        </section>


        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>


    <!-- ================= JAVASCRIPT ================= -->

    <script>

        function toggleMenu() {

            const menu = document.getElementById("menu");

            menu.classList.toggle("show");

        }

    </script>


</body>

</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/beranda.blade.php ENDPATH**/ ?>