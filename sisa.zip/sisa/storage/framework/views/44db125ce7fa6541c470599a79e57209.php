
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Profil - UPTD Litbang Keramik</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/profil.css')); ?>">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="content">

        <!-- ==================================
             PROFIL DAN FOTO
        =================================== -->

        <section class="profile-top">

            <!-- KIRI: TEKS PROFIL -->
            <div class="profile-text">

                <h1>PROFIL</h1>

                <h2><?php echo e($profil->judul ?? 'UPTD LITBANG KERAMIK'); ?></h2>

                <!-- DESKRIPSI -->
                <div class="description">
                    <?php echo $data['deskripsi'] ?? ''; ?>

                </div>

            </div>


            <!-- KANAN: FOTO PROFIL -->
            <div class="profile-image">

                <?php if($profil && $profil->gambar): ?>

                    <img
                        src="<?php echo e(asset('storage/' . $profil->gambar)); ?>"
                        alt="<?php echo e($profil->judul); ?>">

                <?php else: ?>

                    <img
                        src="<?php echo e(asset('img/gedung.jpg')); ?>"
                        alt="Gedung UPTD Litbang Keramik">

                <?php endif; ?>

            </div>

        </section>


        <!-- ==================================
             SEJARAH FULL WIDTH
        =================================== -->

        <section class="history">

            <h2>SEJARAH KERAMIK PLERED</h2>

            <div class="history-line"></div>

            <p>
                <?php echo nl2br(e($data['sejarah'] ?? '')); ?>

            </p>

        </section>


        <!-- ==================================
             VISI DAN MISI
        =================================== -->

        <section class="vision-mission">

            <h2>VISI &amp; MISI</h2>

            <div class="title-line"></div>

            <div class="vision-mission-content">

                <!-- VISI -->
                <div class="vision">

                    <h3>VISI:</h3>

                    <p>
                        <?php echo nl2br(e($data['visi'] ?? '')); ?>

                    </p>

                </div>


                <!-- MISI -->
                <div class="mission">

                    <h3>MISI:</h3>

                    <ol>

                        <?php $__currentLoopData = preg_split('/\r\n|\r|\n/', $data['misi'] ?? ''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if(trim($misi) !== ''): ?>

                                <li><?php echo e($misi); ?></li>

                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ol>

                </div>

            </div>

        </section>

    </main>


    <!-- FOOTER -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- SCRIPT NAVBAR -->
    <script>

        function toggleMenu() {

            const menu = document.getElementById("menu");

            menu.classList.toggle("show");

        }

    </script>

</body>

</html>
<?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/profil.blade.php ENDPATH**/ ?>