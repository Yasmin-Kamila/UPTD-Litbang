<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Artikel - UPTD Litbang Keramik</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/artikel.css')); ?>">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

</head>

<body>

<div class="website">

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ================= ARTIKEL ================= -->

    <main class="artikel">

        <h1>
            ARTIKEL
        </h1>

        <div class="artikel-grid">

            <?php $__empty_1 = true; $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <article class="artikel-card">

                    <!-- GAMBAR -->

                    <div class="artikel-image">

                        <?php if($item->gambar): ?>

                            <img
                                src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                                alt="<?php echo e($item->judul); ?>">

                        <?php else: ?>

                            <img
                                src="<?php echo e(asset('images/kegiatan1.jpg')); ?>"
                                alt="<?php echo e($item->judul); ?>">

                        <?php endif; ?>

                    </div>


                    <!-- INFORMASI ARTIKEL -->

                    <div class="artikel-content">

                        <div class="tanggal">

                            <i class="fa-regular fa-calendar"></i>

                            <?php if($item->tanggal): ?>
                                <?php echo e(\Carbon\Carbon::parse($item->tanggal)->translatedFormat('d F Y')); ?>

                            <?php endif; ?>

                        </div>


                        <h2>
                            <?php echo e($item->judul); ?>

                        </h2>


                        <p class="artikel-isi">

                            <?php echo e(\Illuminate\Support\Str::limit(strip_tags($item->isi), 150)); ?>


                        </p>


                        <!-- TOMBOL DETAIL -->

                        <a href="<?php echo e(route('artikel.detail', $item->id_artikel)); ?>"
                           class="baca-selengkapnya">

                            Baca Selengkapnya

                            <i class="fa-solid fa-arrow-right"></i>

                        </a>

                    </div>

                </article>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div class="artikel-kosong">

                    <i class="fa-solid fa-circle-info"></i>

                    <p>
                        Belum ada artikel yang tersedia.
                    </p>

                </div>

            <?php endif; ?>

        </div>

    </main>


    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

    function toggleMenu() {

        const menu = document.getElementById("menu");

        menu.classList.toggle("show");

    }

</script>

</body>
</html><?php /**PATH C:\laragon\www\webuptdlitbang\resources\views/artikel.blade.php ENDPATH**/ ?>